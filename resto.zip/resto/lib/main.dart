import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: RestoranProfile(),
    );
  }
}

class RestoranProfile extends StatelessWidget {
  // Alamat email, nomor telepon, dan koordinat
  final String email = "restoran@example.com";
  final String phone = "+628123456789";
  final String mapsUrl = "https://www.google.com/maps/search/?api=1&query=-6.9822739,110.4092879";

  // Fungsi untuk membuka aplikasi email
  Future<void> _launchEmail() async {
    final Uri emailUri = Uri(
      scheme: 'mailto',
      path: email,
      queryParameters: {
        'subject': 'Tanya Seputar Resto'
      },
    );
    await _launchUrl(emailUri.toString());
  }

  // Fungsi untuk membuka aplikasi telepon
  Future<void> _launchPhone() async {
    final Uri phoneUri = Uri(
      scheme: 'tel',
      path: phone,
    );
    await _launchUrl(phoneUri.toString());
  }

  // Fungsi untuk membuka peta dengan lokasi UDINUS
  Future<void> _launchMaps() async {
    await _launchUrl(mapsUrl);
  }

  // Fungsi umum untuk meluncurkan URL
  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil Restoran'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Nama Restoran
              Text(
                'Rm. Sedap Rasa',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),

              // Gambar Profil dari Assets
              Container(
                width: double.infinity,
                height: 150,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/resto.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              SizedBox(height: 16),

              // Ikon Email, Map, Telepon
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                    icon: Icon(Icons.email, color: Colors.blue),
                    onPressed: _launchEmail,
                  ),
                  IconButton(
                    icon: Icon(Icons.map, color: Colors.green),
                    onPressed: _launchMaps,
                  ),
                  IconButton(
                    icon: Icon(Icons.phone, color: Colors.red),
                    onPressed: _launchPhone,
                  ),
                ],
              ),
              SizedBox(height: 16),

              // Deskripsi Restoran
              Text(
                'Deskripsi:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text(
                'Restoran ini menyajikan berbagai makanan enak dengan suasana yang nyaman.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 16),

              // List Menu
              Text(
                'List Menu:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text('1. Nasi Goreng\n2. Mie Ayam\n3. Sate Ayam', style: TextStyle(fontSize: 16)),
              SizedBox(height: 16),

              // Alamat
              Text(
                'Alamat:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text('Jl. Imam Bonjol No. 207, Semarang', style: TextStyle(fontSize: 16)),
              SizedBox(height: 16),

              // Jam Buka
              Text(
                'Jam Buka:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text('Senin - Jumat: 08.00 - 22.00\nSabtu - Minggu: 09.00 - 23.00', style: TextStyle(fontSize: 16)),
            ],
          ),
        ),
      ),
    );
  }
}
